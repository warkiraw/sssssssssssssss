from django.contrib import admin
from .models import ExcelFile, ExcelSheet, BankData

@admin.register(ExcelFile)
class ExcelFileAdmin(admin.ModelAdmin):
    list_display = ('file_name', 'uploaded_at')
    search_fields = ('file_name',)

@admin.register(ExcelSheet)
class ExcelSheetAdmin(admin.ModelAdmin):
    list_display = ('sheet_name', 'excel_file', 'sheet_index')
    list_filter = ('excel_file',)
    search_fields = ('sheet_name',)

@admin.register(BankData)
class BankDataAdmin(admin.ModelAdmin):
    list_display = ('bank_name', 'sheet', 'assets', 'portfolio_total', 'portfolio_repo', 'income')
    list_filter = ('sheet__excel_file', 'sheet')
    search_fields = ('bank_name',)
