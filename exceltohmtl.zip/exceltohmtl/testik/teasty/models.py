from django.db import models

# Create your models here.

class ExcelFile(models.Model):
    file_name = models.CharField(max_length=255, verbose_name="Имя файла")
    uploaded_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата загрузки")
    file_data = models.BinaryField(verbose_name="Данные файла")
    
    def __str__(self):
        return self.file_name
    
    class Meta:
        verbose_name = "Excel файл"
        verbose_name_plural = "Excel файлы"

class ExcelSheet(models.Model):
    excel_file = models.ForeignKey(ExcelFile, on_delete=models.CASCADE, related_name="sheets", verbose_name="Excel файл")
    sheet_name = models.CharField(max_length=255, verbose_name="Имя листа")
    sheet_index = models.IntegerField(verbose_name="Индекс листа")
    
    def __str__(self):
        return f"{self.excel_file.file_name} - {self.sheet_name}"
    
    class Meta:
        verbose_name = "Лист Excel"
        verbose_name_plural = "Листы Excel"
        unique_together = ['excel_file', 'sheet_index']

class BankData(models.Model):
    sheet = models.ForeignKey(ExcelSheet, on_delete=models.CASCADE, related_name="bank_data", verbose_name="Лист Excel")
    row_index = models.IntegerField(verbose_name="Индекс строки")
    bank_name = models.CharField(max_length=255, verbose_name="Наименование банка")
    assets = models.DecimalField(max_digits=20, decimal_places=2, null=True, blank=True, verbose_name="Активы")
    portfolio_total = models.DecimalField(max_digits=20, decimal_places=2, null=True, blank=True, verbose_name="Ссудный портфель (всего)")
    portfolio_repo = models.DecimalField(max_digits=20, decimal_places=2, null=True, blank=True, verbose_name="Операции 'Обратное РЕПО'")
    income = models.DecimalField(max_digits=20, decimal_places=2, null=True, blank=True, verbose_name="Превышение доходов/расходов")
    
    def __str__(self):
        return f"{self.bank_name} ({self.sheet})"
    
    class Meta:
        verbose_name = "Данные банка"
        verbose_name_plural = "Данные банков"
        unique_together = ['sheet', 'row_index']
