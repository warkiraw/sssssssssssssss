from django.shortcuts import render
import pandas as pd
import numpy as np
import io
import base64
from .models import ExcelFile, ExcelSheet, BankData
from decimal import Decimal
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.middleware.csrf import get_token

def format_number(x):
    try:
        if pd.isna(x) or x == 0:
            return ''
        return '{:,.0f}'.format(float(x)).replace(',', ' ')  # Используем пробел как разделитель тысяч
    except:
        return str(x)

def parse_number(x):
    """Преобразует строку в Decimal для сохранения в БД"""
    try:
        if pd.isna(x) or x == '' or x == 0:
            return None
        if isinstance(x, str):
            x = x.replace(' ', '')
        return Decimal(str(float(x)))
    except:
        return None

def get_csrf_token(request):
    """Возвращает CSRF токен для JavaScript"""
    csrf_token = get_token(request)
    return JsonResponse({'csrfToken': csrf_token})

@csrf_exempt
def upload_file(request):
    # Если это GET запрос с параметром sheet, значит это переключение страницы
    if request.method == 'GET' and 'sheet' in request.GET and 'excel_data' in request.session:
        try:
            # Получаем сохраненные данные из сессии и декодируем из base64
            excel_data = base64.b64decode(request.session['excel_data'])
            file_name = request.session['file_name']
            
            # Создаем объект ExcelFile из сохраненных данных
            excel_file = pd.ExcelFile(io.BytesIO(excel_data))
            sheet_names = excel_file.sheet_names
            
            # Получаем номер страницы
            current_page = request.GET.get('sheet', 0)
            try:
                current_page = int(current_page)
                if current_page >= len(sheet_names):
                    current_page = 0
            except:
                current_page = 0
            
            # Читаем выбранный лист
            df = pd.read_excel(excel_file, sheet_name=sheet_names[current_page])
            
        except Exception as e:
            print(f"Error occurred while switching sheets: {e}")
            return render(request, 'upload.html', {'error': f"Ошибка при переключении страницы: {str(e)}"})
            
    # Если это POST запрос с новым файлом
    elif request.method == 'POST' and request.FILES.get('file'):
        try:
            file = request.FILES['file']
            
            # Сохраняем данные файла в сессии в формате base64
            file_data = file.read()
            request.session['excel_data'] = base64.b64encode(file_data).decode('utf-8')
            request.session['file_name'] = file.name
            
            # Создаем объект ExcelFile
            excel_file = pd.ExcelFile(io.BytesIO(file_data))
            sheet_names = excel_file.sheet_names
            current_page = 0
            
            # Сохраняем файл в БД
            db_file = ExcelFile.objects.create(
                file_name=file.name,
                file_data=file_data
            )
            
            # Сохраняем информацию о листах
            for idx, sheet_name in enumerate(sheet_names):
                ExcelSheet.objects.create(
                    excel_file=db_file,
                    sheet_name=sheet_name,
                    sheet_index=idx
                )
                
                # Читаем данные каждого листа и сохраняем их
                df_sheet = pd.read_excel(excel_file, sheet_name=sheet_name)
                save_sheet_data(df_sheet, db_file, idx, sheet_name)
            
            # Читаем первый лист для отображения
            df = pd.read_excel(excel_file, sheet_name=sheet_names[current_page])
            
        except Exception as e:
            print(f"Error occurred while uploading: {e}")
            return render(request, 'upload.html', {'error': f"Ошибка при обработке файла: {str(e)}"})
    else:
        return render(request, 'upload.html')
    
    try:
        # Общая обработка данных для обоих случаев
        # Удаляем дублирующиеся заголовки
        mask = (pd.to_numeric(df.iloc[:, 0], errors='coerce').notna()) | \
               (df.iloc[:, 0].astype(str).str.contains('Итого', case=False)) | \
               ((df.iloc[:, 1].notna() & df.iloc[:, 2].notna()) & \
                ~(df.iloc[:, 1].astype(str).str.contains('Наименование', case=False)))  # Исключаем строки с "Наименование"
        
        df = df[mask]
        
        df_selected = pd.DataFrame({
            'bank_name': df.iloc[:, 1],  # Наименование банка
            'assets': df.iloc[:, 2],     # Активы
            'portfolio_total': df.iloc[:, 3],  # Ссудный портфель (всего)
            'portfolio_repo': df.iloc[:, 4],   # Операции "Обратное РЕПО"
            'income': df.iloc[:, 17]     # Превышение доходов/расходов
        })
        
        # Форматируем числовые значения
        for col in ['assets', 'portfolio_total', 'portfolio_repo', 'income']:
            df_selected[col] = df_selected[col].apply(format_number)
        
        # Преобразуем в список словарей
        result_data = df_selected.to_dict('records')
        
        # Подготавливаем информацию о страницах
        sheets_info = [{'index': idx, 'name': name} for idx, name in enumerate(sheet_names)]
        
        return render(request, 'result.html', {
            'data': result_data,
            'sheets': sheets_info,
            'current_sheet': current_page,
            'file_name': request.session['file_name']
        })
        
    except Exception as e:
        print(f"Error occurred in data processing: {e}")
        return render(request, 'upload.html', {'error': f"Ошибка при обработке данных: {str(e)}"})

def save_sheet_data(df, db_file, sheet_idx, sheet_name):
    """Сохраняет данные листа в БД"""
    try:
        # Получаем объект листа
        sheet = ExcelSheet.objects.get(excel_file=db_file, sheet_index=sheet_idx)
        
        # Применяем ту же маску для фильтрации данных
        mask = (pd.to_numeric(df.iloc[:, 0], errors='coerce').notna()) | \
               (df.iloc[:, 0].astype(str).str.contains('Итого', case=False)) | \
               ((df.iloc[:, 1].notna() & df.iloc[:, 2].notna()) & \
                ~(df.iloc[:, 1].astype(str).str.contains('Наименование', case=False)))
        
        df = df[mask]
        
        # Создаем записи для каждой строки данных
        for idx, row in df.iterrows():
            bank_name = row.iloc[1]
            
            # Проверяем, что у нас есть название банка
            if pd.notna(bank_name) and str(bank_name).strip():
                BankData.objects.create(
                    sheet=sheet,
                    row_index=idx,
                    bank_name=str(bank_name).strip(),
                    assets=parse_number(row.iloc[2]),
                    portfolio_total=parse_number(row.iloc[3]),
                    portfolio_repo=parse_number(row.iloc[4]),
                    income=parse_number(row.iloc[17])
                )
    except Exception as e:
        print(f"Error saving sheet data {sheet_name}: {e}")
