# Excel в HTML - Конвертер финансовых данных

Приложение для преобразования Excel-файлов с финансовыми данными банков в удобный для просмотра HTML-формат.

## 📋 Возможности проекта

- Загрузка Excel-файлов через веб-интерфейс
- Автоматическая обработка данных финансовой отчетности
- Отображение ключевых финансовых показателей (активы, ссудный портфель, операции РЕПО, доходы)
- Поддержка многостраничных Excel-файлов с возможностью переключения между листами
- Форматирование числовых значений для удобного просмотра

## 🛠️ Технологии

- Django
- Python 
- Pandas для обработки Excel-файлов
- HTML/CSS для пользовательского интерфейса

## 🚀 Установка и запуск

### Предварительные требования

- Python 
- pip (менеджер пакетов Python)

### Шаг 1: Старта

Открываем Powershell или нажимаем win + R и пишем cmd

Пишем cd Desktop

```
### Шаг 2: Создание папки

```bash
mkdir project
cd project
```

### Шаг 3: Создание проекта Django

```bash
django-admin startproject testik
cd testik
```

### Шаг 4: Создание приложения

```bash
python manage.py startapp teasty
```

### Шаг 5: Установка зависимостей

```bash
pip install django pandas numpy
```

### Шаг 6: Настройка проекта

1. Откройте файл `testik/settings.py` и добавьте приложение в список `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'teasty',  # Добавьте это
]
```

2. Настройте URL-маршруты в файле `testik/urls.py`:

```python
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('teasty.urls')),
]
```

3. Создайте файл `teasty/urls.py` с содержимым:

```python
from django.urls import path
from . import views

urlpatterns = [
    path('', views.upload_file, name='upload_file'),
]
```

### Шаг 7: Создание представлений (views)

Создайте файл `teasty/views.py` со следующим содержимым:

```python
from django.shortcuts import render
import pandas as pd
import numpy as np
import io
import base64

def format_number(x):
    try:
        if pd.isna(x) or x == 0:
            return ''
        return '{:,.0f}'.format(float(x)).replace(',', ' ')  # Используем пробел как разделитель тысяч
    except:
        return str(x)

def upload_file(request):
    # Если это GET запрос с параметром sheet, значит это переключение страницы
    if request.method == 'GET' and 'sheet' in request.GET and 'excel_data' in request.session:
        try:
            # Получаем сохраненные данные из сессии и декодируем из base64
            excel_data = base64.b64decode(request.session['excel_data'])
            file_name = request.session['file_name']
            
            # Создаем объект ExcelFile из сохраненных данных
            excel_file = pd.ExcelFile(io.BytesIO(excel_data))
            sheet_names = excel_file.sheet_names
            
            # Получаем номер страницы
            current_page = request.GET.get('sheet', 0)
            try:
                current_page = int(current_page)
                if current_page >= len(sheet_names):
                    current_page = 0
            except:
                current_page = 0
            
            # Читаем выбранный лист
            df = pd.read_excel(excel_file, sheet_name=sheet_names[current_page])
            
        except Exception as e:
            print(f"Error occurred while switching sheets: {e}")
            return render(request, 'upload.html', {'error': f"Ошибка при переключении страницы: {str(e)}"})
            
    # Если это POST запрос с новым файлом
    elif request.method == 'POST' and request.FILES.get('file'):
        try:
            file = request.FILES['file']
            
            # Сохраняем данные файла в сессии в формате base64
            file_data = file.read()
            request.session['excel_data'] = base64.b64encode(file_data).decode('utf-8')
            request.session['file_name'] = file.name
            
            # Создаем объект ExcelFile
            excel_file = pd.ExcelFile(io.BytesIO(file_data))
            sheet_names = excel_file.sheet_names
            current_page = 0
            
            # Читаем первый лист
            df = pd.read_excel(excel_file, sheet_name=sheet_names[current_page])
            
        except Exception as e:
            print(f"Error occurred while uploading: {e}")
            return render(request, 'upload.html', {'error': f"Ошибка при обработке файла: {str(e)}"})
    else:
        return render(request, 'upload.html')
    
    try:
        # Общая обработка данных для обоих случаев
        # Удаляем дублирующиеся заголовки
        mask = (pd.to_numeric(df.iloc[:, 0], errors='coerce').notna()) | \
               (df.iloc[:, 0].astype(str).str.contains('Итого', case=False)) | \
               ((df.iloc[:, 1].notna() & df.iloc[:, 2].notna()) & \
                ~(df.iloc[:, 1].astype(str).str.contains('Наименование', case=False)))  # Исключаем строки с "Наименование"
        
        df = df[mask]
        
        df_selected = pd.DataFrame({
            'bank_name': df.iloc[:, 1],  # Наименование банка
            'assets': df.iloc[:, 2],     # Активы
            'portfolio_total': df.iloc[:, 3],  # Ссудный портфель (всего)
            'portfolio_repo': df.iloc[:, 4],   # Операции "Обратное РЕПО"
            'income': df.iloc[:, 17]     # Превышение доходов/расходов
        })
        
        # Форматируем числовые значения
        for col in ['assets', 'portfolio_total', 'portfolio_repo', 'income']:
            df_selected[col] = df_selected[col].apply(format_number)
        
        # Преобразуем в список словарей
        result_data = df_selected.to_dict('records')
        
        # Подготавливаем информацию о страницах
        sheets_info = [{'index': idx, 'name': name} for idx, name in enumerate(sheet_names)]
        
        return render(request, 'result.html', {
            'data': result_data,
            'sheets': sheets_info,
            'current_sheet': current_page,
            'file_name': request.session['file_name']
        })
        
    except Exception as e:
        print(f"Error occurred in data processing: {e}")
        return render(request, 'upload.html', {'error': f"Ошибка при обработке данных: {str(e)}"})
```

### Шаг 8: Создание шаблонов

1. Создайте директорию шаблонов:

```bash
mkdir -p teasty/templates
```

2. Создайте файл `teasty/templates/upload.html`:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Загрузка файла</title>
    <style>
        body {
            font-family: 'Roboto', 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #212529;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .container {
            max-width: 600px;
            width: 90%;
            background-color: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            text-align: center;
        }
        
        .header {
            margin-bottom: 30px;
            border-bottom: 2px solid #3c6382;
            padding-bottom: 20px;
        }
        
        .header h1 {
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .header p {
            color: #7f8c8d;
            font-size: 16px;
            margin-top: 0;
        }
        
        .upload-form {
            margin: 30px 0;
        }
        
        .file-input-container {
            position: relative;
            margin: 20px auto;
            max-width: 350px;
        }
        
        .file-input {
            position: relative;
            text-align: right;
            opacity: 0;
            z-index: 2;
            cursor: pointer;
            height: 50px;
            max-width: 350px;
            width: 100%;
        }
        
        .file-input-label {
            position: absolute;
            top: 0;
            right: 0;
            left: 0;
            z-index: 1;
            height: 50px;
            padding: 0 15px;
            background-color: #fff;
            border: 2px dashed #3c6382;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7f8c8d;
            font-size: 15px;
            transition: all 0.3s;
        }
        
        .file-input:hover + .file-input-label,
        .file-input:focus + .file-input-label {
            border-color: #0984e3;
            background-color: #f1f9ff;
        }
        
        .file-name {
            margin-top: 10px;
            font-size: 14px;
            color: #3c6382;
            word-break: break-all;
            display: none;
        }
        
        .upload-btn {
            background-color: #3c6382;
            color: white;
            border: none;
            padding: 12px 30px;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
            width: 100%;
            max-width: 350px;
        }
        
        .upload-btn:hover, .upload-btn:focus {
            background-color: #0984e3;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(9,132,227,0.2);
        }
        
        .upload-btn:active {
            transform: translateY(0);
        }
        
        .error-message {
            color: #e74c3c;
            margin: 20px 0;
            padding: 15px;
            background-color: #ffeaea;
            border-radius: 8px;
            border-left: 4px solid #e74c3c;
            text-align: left;
            display: none;
        }
        
        .error-message.show {
            display: block;
        }
        
        .upload-icon {
            display: inline-block;
            margin-right: 10px;
            vertical-align: middle;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Загрузка Excel файла</h1>
            <p>Загрузите файл Excel для преобразования в удобный HTML формат</p>
        </div>
        
        <form method="post" enctype="multipart/form-data" class="upload-form">
            {% csrf_token %}
            
            <div class="file-input-container">
                <input type="file" name="file" id="file" class="file-input" accept=".xlsx, .xls" required>
                <label for="file" class="file-input-label">
                    <span class="upload-icon">📄</span> Выберите Excel файл
                </label>
            </div>
            
            <div id="file-name" class="file-name"></div>
            
            <button type="submit" class="upload-btn">Загрузить и обработать</button>
            
            {% if error %}
            <div class="error-message show">
                {{ error }}
            </div>
            {% endif %}
        </form>
    </div>
    
    <script>
        // Отображение имени выбранного файла
        document.getElementById('file').addEventListener('change', function() {
            const fileName = this.files[0] ? this.files[0].name : '';
            const fileNameContainer = document.getElementById('file-name');
            
            if (fileName) {
                fileNameContainer.textContent = 'Выбран файл: ' + fileName;
                fileNameContainer.style.display = 'block';
            } else {
                fileNameContainer.style.display = 'none';
            }
        });
    </script>
</body>
</html>
```

3. Создайте файл `teasty/templates/result.html`:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Финансовые показатели банков</title>
    <style>
        body {
            font-family: 'Roboto', 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #212529;
        }
        
        .container {
            max-width: 1400px;
            margin: 30px auto;
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #3c6382;
            padding-bottom: 20px;
        }
        
        .header h1 {
            color: #2c3e50;
            font-size: 32px;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 30px;
            background-color: white;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            border-radius: 10px;
            overflow: hidden;
            table-layout: fixed;
        }
        
        th, td {
            padding: 15px 20px;
            text-align: right;
            border-bottom: 1px solid #e0e0e0;
        }
        
        th {
            background-color: #3c6382;
            color: white;
            font-weight: 600;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
        }
        
        th:first-child, td:first-child {
            text-align: left;
            width: 40%;
        }
        
        tr:hover td {
            background-color: #f5f9fc;
        }
        
        .sheet-tabs {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 30px;
        }
        
        .sheet-tab {
            padding: 10px 20px;
            background-color: #e0e0e0;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s;
            color: #333;
            text-decoration: none;
            font-size: 14px;
        }
        
        .sheet-tab:hover {
            background-color: #d0d0d0;
        }
        
        .sheet-tab.active {
            background-color: #3c6382;
            color: white;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #3c6382;
            text-decoration: none;
            font-weight: 500;
            padding: 10px 15px;
            border: 1px solid #3c6382;
            border-radius: 8px;
            transition: all 0.2s;
        }
        
        .back-link:hover {
            background-color: #3c6382;
            color: white;
        }
        
        .table-container {
            overflow-x: auto;
            margin-top: 20px;
        }
        
        .file-info {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 20px;
            text-align: center;
        }
        
        /* Стили для мобильных устройств */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
                margin: 15px;
                width: auto;
            }
            
            th, td {
                padding: 10px;
                font-size: 14px;
            }
            
            .header h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Финансовые показатели банков</h1>
            <p class="file-info">Файл: {{ file_name }}</p>
        </div>
        
        {% if sheets|length > 1 %}
        <div class="sheet-tabs">
            {% for sheet in sheets %}
                <a href="?sheet={{ sheet.index }}" class="sheet-tab {% if sheet.index == current_sheet %}active{% endif %}">
                    {{ sheet.name }}
                </a>
            {% endfor %}
        </div>
        {% endif %}
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Наименование банка</th>
                        <th>Активы</th>
                        <th>Ссудный портфель (всего)</th>
                        <th>Операции "Обратное РЕПО"</th>
                        <th>Чистая прибыль/(убыток)</th>
                    </tr>
                </thead>
                <tbody>
                    {% for row in data %}
                        <tr>
                            <td>{{ row.bank_name }}</td>
                            <td>{{ row.assets }}</td>
                            <td>{{ row.portfolio_total }}</td>
                            <td>{{ row.portfolio_repo }}</td>
                            <td>{{ row.income }}</td>
                        </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        
        <a href="/" class="back-link">Загрузить новый файл</a>
    </div>
</body>
</html>
```

### Шаг 9: Запуск миграций

```bash
python manage.py makemigrations
python manage.py migrate
```

### Шаг 10: Запуск сервера разработки

```bash
python manage.py runserver
```

После выполнения этой команды ваше приложение будет доступно по адресу [http://127.0.0.1:8000/](http://127.0.0.1:8000/)

## 🧪 Тестирование

Загрузите любой Excel-файл с финансовыми показателями банков, имеющий следующие столбцы:
- Столбец 1: Номер п/п
- Столбец 2: Наименование банка
- Столбец 3: Активы
- Столбец 4: Ссудный портфель (всего)
- Столбец 5: Операции "Обратное РЕПО"
- Столбец 18: Превышение доходов/расходов (Чистая прибыль/убыток)

## 💡 Дополнительно

### Структура проекта

```
exceltohmtl/
├── venv/                 # Виртуальное окружение
├── testik/               # Проект Django
│   ├── testik/           # Настройки проекта
│   │   ├── __init__.py
│   │   ├── settings.py   # Настройки проекта
│   │   ├── urls.py       # URL-маршруты проекта
│   │   ├── wsgi.py
│   │   └── asgi.py
│   ├── teasty/           # Приложение для обработки данных
│   │   ├── migrations/   # Миграции базы данных
│   │   ├── templates/    # Шаблоны HTML
│   │   │   ├── upload.html  # Страница загрузки файла
│   │   │   └── result.html  # Страница результатов
│   │   ├── __init__.py
│   │   ├── admin.py
│   │   ├── apps.py
│   │   ├── models.py
│   │   ├── tests.py
│   │   ├── urls.py      # URL-маршруты приложения
│   │   └── views.py     # Логика обработки запросов
│   ├── manage.py        # Утилита управления Django
│   └── db.sqlite3       # База данных SQLite
└── README.md            # Этот файл
```
